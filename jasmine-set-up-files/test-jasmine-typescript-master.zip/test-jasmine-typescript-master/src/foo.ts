export class Foo {
    static bar() {
        return 'bar';
    }
}
