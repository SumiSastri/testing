# test-jasmine-typescript

[![dependencies](https://david-dm.org/piecioshka/test-jasmine-typescript.svg)](https://github.com/piecioshka/test-jasmine-typescript)
[![travis-ci](https://api.travis-ci.org/piecioshka/test-jasmine-typescript.svg?branch=master)](https://travis-ci.org/piecioshka/test-jasmine-typescript)
[![coveralls](https://coveralls.io/repos/github/piecioshka/test-jasmine-typescript/badge.svg?branch=master)](https://coveralls.io/github/piecioshka/test-jasmine-typescript?branch=master)
[![snyk](https://snyk.io/test/github/piecioshka/test-jasmine-typescript/badge.svg?targetFile=package.json)](https://snyk.io/test/github/piecioshka/test-jasmine-typescript?targetFile=package.json)


:ledger: Test project with Jasmine & TypeScript

## Unit tests

```bash
npm test
```

## Related

* [test-mocha-typescript](https://github.com/piecioshka/test-mocha-typescript)

## License

[The MIT License](http://piecioshka.mit-license.org) @ 2018
