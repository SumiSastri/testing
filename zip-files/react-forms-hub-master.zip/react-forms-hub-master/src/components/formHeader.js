import React from 'react';

const FormHeader = () => {
	return (
		<div>
			<h1>Form Header</h1>
		</div>
	);
};
export default FormHeader;
