import React, { Component } from 'react';
import NameAddress from './nameAddress';
import FormHeader from './formHeader';
import FormFooter from './formFooter';

class MainForm extends Component {
	render() {
		return (
			<div>
				<FormHeader />
				<NameAddress />
				<FormFooter />
			</div>
		);
	}
}
export default MainForm;
