import React from 'react';

const FormFooter = () => {
	return (
		<div>
			<h4>Form Footer</h4>
		</div>
	);
};
export default FormFooter;
