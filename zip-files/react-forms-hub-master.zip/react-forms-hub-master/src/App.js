import React from 'react';
import MainForm from './components/mainForm';

function App() {
	return (
		<div className="Form-Hub-Main">
			<MainForm />
		</div>
	);
}

export default App;
