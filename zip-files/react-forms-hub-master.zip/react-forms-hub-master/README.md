
## `React-forms a how-to-guide'

### `Introduction - basic concepts`
HTML is stateful - when you type in an input into a form it recognises the change in the input value and updates the respective values.

React is stateless - it works in the virtual DOM, therefore state needs to be set and changes to state defined

In a form data (or the variables in state) change with user inputs therefore state is constantly being updated and mutated,  or in other words, the data input into the form fields are changed every time the user inputs their details.

These input fields whether text, select radio buttons, drop-down menus are constantly being altered by the user.

To capture these changes, event handlers are created.

Events are changes in the document object model (DOM) that can be triggered by event listeners. This is especially useful with form submission.

Users may scroll a page, click a button, leave a form half-filled and exit the page, have difficulty filling in forms and all of this data is stored in the browser. This information can be used to improve the user experience as well as capture data for back-end data-bases.

This project is to create a library of re-usable form components. Key concepts of state, destructuring, the use of spread operators, and explore various baked-in methods (functions) that can be used and re-used for later projects.

### Useful Tutorials

Code Evolution - YouTube
A 15-minute video with both theory behind form creation and useful form components

GA Textbook - revision

### `Set up`
Dev tools 
 - Visual Studio (IDE)
 - Node Package Manager (NPM)
 - Google console

In terminal run create react app
Component files
 - main form (imports all inputs and then exported in main app)
 - name address (personal details, all text inputs)
 - filter (drop down menu)
 - radio buttons (2 options and mutliple options)
 - check-boxes (2 options and mutliple options)
 - date picker (react calender)
 - search-box (search through form information)

#### `Main App`

Create your main app 

```
import React from 'react';


function App() {
	return (
		<div className="Forms">
			<header className="Forms-Hub">
				<h1> Forms Hub </h1>
			</header>
		</div>
	);
}

export default App;
```

TEST APP WORKS: Open google developer console and the React performance tab in console to check on the local host (yarn run start to set up local host)

#### `Main Form Hub`

Create your main form hub component - here you can pick and mix what you want rendered from the other components 

```
import React, { Component } from 'react';


class MainForm extends Component {
	render() {
		return (
			<form>
				<div>
					<label>First Name:</label>
					<input type="text" />
				</div>
			</form>
		);
	}
}
export default MainForm;
```

#### `Test the Form Hub is working`

```
import React from 'react';
import MainForm from './components/mainForm';

function App() {
	return (
		<div className="Forms">
			<header className="Forms-Hub">
				<h1> Forms Hub </h1>
				<MainForm />
			</header>
		</div>
	);
}

export default App;
```

#### `Create your first component that feeds into the Form Hub`

import React, { Component } from 'react';

```
class NameAddress extends Component {
	render() {
		return (
			<form>
				<div>
					<label>First Name:</label>
					<input type="text" />
				</div>
			</form>
		);
	}
}
export default NameAddress;
```

#### `Export and Import it to the Form Hub`

Test that this works in the main app as well - now you do not need to change the main App and all changes can be exported into the main form hub.

import React, { Component } from 'react';
import NameAddress from './nameAddress';

```
class MainForm extends Component {
	render() {
		return (
			<form>
				<div>
					<NameAddress />
				</div>
			</form>
		);
	}
}
export default MainForm;
```
Now you know that the imports are working create the components without any styling - you can then style each component and form to requirements.

This template should serve most requirements for personal name, address details

```
import React, { Component } from 'react';

class NameAddress extends Component {
	render() {
		return (
			<form>
				<div>
					<label>First Name:</label>
					<input type="text" placeholder="FirstName" />
				</div>

				<div>
					<label>Middle Name or Initial:</label>
					<input type="text" placeholder="Middle Name or Initial" />
				</div>

				<div>
					<label>Family Name:</label>
					<input type="text" placeholder="Family Name" />
				</div>
				<div>
					<label>Address1:</label>
					<input type="text" placeholder="First line of address" />
				</div>
				<div>
					<label>Address2:</label>
					<input type="text" placeholder="Second line of address" />
				</div>
				<div>
					<label>Address3:</label>
					<input type="text" placeholder="Third line of address" />
				</div>
				<div>
					<label>City:</label>
					<input type="text" placeholder="City" />
				</div>
				<div>
					<label>PostCode:</label>
					<input type="text" placeholder="Post Code" />
				</div>
				<div>
					<label>Country:</label>
					<input type="text" placeholder="Country" />
				</div>
			</form>
		);
	}
}
export default NameAddress;

```

### `Stateful and state-less components`

Controlled components:

In a controlled form you manage state within the State constructor of the form, it is called a stateful component.

State - holds the data in the forms. In a stateful component the first step is to

1. Set state 

Each input field - name, address, check boxes,etc., has data that changes each time the user updates the field. To capture this data we set state in the component.

We then initialise these values so that we know exactly how to target these changes.

Components are written in ES6 to build constructors - or blue prints for new objects therefore class Form is the constructor creating a new object {} that can be used as a blue-print in other sections of the app

In that object the function super needs to be called super()  properties or ES5 parameters - this acts just like js params and are local variables to "state". The propertiess are the values of data that passed into new blue-print  data object (Note: you can call the object anything - user details:{}/ values:{}/ etc., instead data)

This creates the new object {} this can be an empty object or hard-coded with the values initialised as empty strings, or empty arrays, booleans, numbers or functions (as with any object). 

import React, { Component } from 'react';

```
import React, { Component } from 'react';

class NameAddress extends Component {
	constructor(props) {
		super(props);

		this.state = {
			personalData: {
				firstName: '',
				middleName: '',
				familyName: '',
				address1: '',
				address2: '',
				address3: '',
				city: '',
				postcode: '',
				country: ''
			}
		};
	}
```
### `rendering "state" values with jsx elements`
2. Create the JSX form element in the render function. Each input must have 

name = name as in the data object
type = text, select, radio, button etc.,
value = empty string (this will be updated by user)
event handlers - onChange & onSubmit (empty strings)

In the console you will get an error message which shows that the event handlers can not be strings

In the empty strings call-back java-script functions will be written, once these functions are created in state  eg:{this.state.firstName} or {this.handleChange}

The event handler for submit is handled at the top of the form, not on the button, while you can do this with an on click event handler on the button, the user experience is better if the change is handled on the top.

optional attributes are
label - tells the user what the field is for
className - For css styling as class is a constructor, therefore a reserved word in react, className should be used to target the jsx element for styling.
placeholder - improves ui-ux as user given instructions on what to do in the empty field
 
```
	render() {
		return (
			<form name="name-address" onSubmit="">
				<div>
					<label>First Name:</label>
					<input
						name="firstName"
						type="text"
						placeholder="FirstName"
						value=""
						className="first-name"
						onChange=""
					/>
				</div>
				
```
TEST: create one jsx element and see if it renders then add the others

### `firing the render method with event handlers`
3. Write your event handler functions - to handle change and handle the submission of the form

```
handleChange =(event) => {
  this.setState({ 
        firstName: event.target.value
})  
}
```

Event handlers target user actions.
The handleChange function param therefore is the event (change based on user typing in new details in text box)

We are mutating state using the setState method baked into React - we do this outside the constructor in a function and can pass every name-value pair like so

```
		handleChange = (event) => {
		this.setState({
			firstName: event.target.value,
			middleName: event.target.value,
			familyName: event.target.value,
			address1: event.target.value,
			address2: event.target.value,
			address3: event.target.value,
			city: event.target.value,
			postcode: event.target.value,
			country: event.target.value
		});
	};
	
```

4. Handle submit
This is written only once at the top of the form and linked to the submit button or command at the bottom of the form

By default if you press the submit button, the Virtual DOM recognises the change and re-renders the page, this function therefore must be written with a prevent default command which has been pre-defined function in React

handleSubmit = event => {
event.preventDefault()
}

### `updating jsx with call-back functions for event handlers`

update all the empty strings with their call back functions and  test in the google console and the react extension that the the values are being updated - test with one and then update the others

```
render() {
		return (
			<form name="name-address" onSubmit={this.handleSubmit}>
				<div>
					<label>First Name:</label>
					<input
						name="firstName"
						type="text"
						placeholder="FirstName"
						value={this.state.firstName}
						className="first-name"
						onChange={this.handleChange}
					/>
				</div>
```

### `keeping code DRY - storing state data as variables - destructuring`

Taking these properties out of the object and storing this data as a local variables is also known as  "destructuring"

eg: const { firstName, lastName } = personalData
This is the same as, just written differently - they all do the same thing store the data as a variable
const personalData = { firstName: '', lastName: '' }
const firstName = personalData.firstName
const email = personalData.email

You can also take the properties out of the object and pass them as params of a function

function printPersonalData({ firstName, email }) {
  return `The name is: ${firstName} and the email is: ${email}`
}

const personalData = { firstname: '', email: '' }

printName(personalData)

What you are doing here is make the params of the function printPersonalData(){} return the properties first name and email in the data object
You are assigning the properties to a variable personalData
Therefore when you invoke the function you get the personal data that you have taken out from the data object in this case only the first name and email for this function and you can call this function in the render method if you wish

The handleChange event handler is verbose - it repeats all the name-value pairs to set state

### `using the spread operator to mutuate state`
To deconstruct the handleChange function we first declare a variable and spread the data in state with the spread operator, another method baked into React like so

```
const data = { ...this.state.data, [name]: value };
```
we deconstruct using the method or function e.target.value

```
handleChange = ({ target: { name, value } })
```
we then set state to this deconstructed version which is DRY code

```
handleChange = ({ target: { name, value } }) => {
		const data = { ...this.state.data, [name]: value };
		this.setState({ data });
	};

```
State now is mutated we need to go into our jsx tag and update it to reflect the new state which is data.firstName, update and test in console

```
					<input
						name="firstName"
						type="text"
						placeholder="FirstName"
						value={this.state.data.firstName}
						className="first-name"
						onChange={this.handleChange}
					/>
```

### `adding functional components - stateless components`

These components render information, they do not contain state and data does not change - headers, footers - or when a form is deconstructed it can be changed to a functional component or a stateless component. No constructor is required and you declare the component as a variable and export it into the main form being rendered.

```
import React from 'react';

const FormHeader = () => {
	return (
		<div>
			<h1>Form Header</h1>
		</div>
	);
};
export default FormHeader;
```
### Rendering from component to main app

We export Form constructor into the main app
In the main app we import the Form constructor and the file-paths
We pass the Form constructor as JSX elements <Form />


The data is submitted to the browser where it can be stored and used or it can be sent via an API to your back end database



## Data flows
The value or data in the input filed is set in state as an empty object
— We then have an event handler that is fired every time there is a change in the input value - this is a method we define outside state and reset state to the new state of the data fields that have changed due to the inputs of the users
— Once this handler targets the data value to be changed it renders it in the render method by targeting the input value that has changed on the onChange event handler function we have defined

The cycle is that the data and values are set in set that fill the fields in the render form jsx tags fired by the event handler that records the changes in state but the this.setState method (this.setState is saying set the new state or data values which have changed because the user has updated them). The input field then populates state with the new information
 - immutable state  becomes mutated state via the event handler functions - mutated state triggered by jsx element changes due to user - data flows back to immutable state and temporarily mutates it - state returns to immutable after the event is fired and completed



      
